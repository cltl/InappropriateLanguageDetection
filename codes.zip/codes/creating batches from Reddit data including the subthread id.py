import os
from detect_delimiter import detect
class MyList(list):
    def last_index(self):
        return len(self)-1
rootdir = '/selection of 100/'
import pandas as pd
import nltk
limit = 0
batch = 0
import re
import unicodedata

from unidecode import unidecode
import ftfy


def remove_weird_characters(string):
    # Fix Unicode text encoding problems
    cleaned_string = ftfy.fix_text(string)

    return cleaned_string
def replace_links_with_placeholder(text, placeholder="[LINK]"):
    # Regular expression pattern to match URLs
    url_pattern = re.compile(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+")

    # Use the sub() function to replace URLs with the placeholder
    replaced_text = re.sub(url_pattern, placeholder, text)

    return replaced_text
def context_extractor(file, index):
    new_context = ''
    if index == 0:
        new_context = '-'
    else:
        upper_range = index + 1
        print('upper range:' , upper_range)
        for i in range(upper_range, 1, -1):
            print('i', i)
            context = file.loc[upper_range - i, 'comment_text']
            print(context)
            user_id = file.loc[upper_range - i, 'author']
            user_id = "[" + user_id + "]"
            context = user_id + ': ' + str(context)
            if i == upper_range:
                new_context = new_context + context
            else:
                new_context = new_context + ' <br> ' + context
    new_context = replace_links_with_placeholder(new_context)
    new_context = remove_weird_characters(new_context)
    return new_context
redirect_url = 'redirecturl'
columns = ['comment_id', 'title_id', 'community_id', 'title_text', 'comment_text_a', 'comment_text_b', 'context', 'comment', 'comment_number', 'subthread_id', 'user_id', 'redirectUrl', 'post_text']
new_df = pd.DataFrame()
context = ''
batch_number = 0
for subdir, dirs, files in os.walk(rootdir):
    for file in files:
        file_path = os.path.join(subdir, file)
        if '.csv' in file_path:
            with open(file_path, newline='', errors='ignore') as csvfile:
                comment_number = 0
                limit += 1
                firstline = csvfile.readline()
                #delimiter = detect(firstline)
                new_file = pd.read_csv(file_path, on_bad_lines='skip')
                file_name = os.path.basename(file_path)
                print(file_name)
                file_name = file_name.split('_')
                print(file_name)
                file_name = file_name[-1]
                subthread = file_name.split('.')
                subthread = subthread[0]
                dataframe_length = len(new_file.index)
                for index, row in new_file.iterrows():
                    comment_id = row['comment_id']
                    comment_number += 1
                    title_id = row['title_id']
                    community_id = row['community_id']
                    title_text = row['title_text']
                    title_text = remove_weird_characters(title_text)
                    title_id = str(title_id)
                    comment_text = row['comment_text']
                    comment_text = str(comment_text)
                    post_text = row['self_text']
                    post_text = str(post_text)
                    post_text = remove_weird_characters(post_text)
                    comment_text = replace_links_with_placeholder(comment_text)
                    comment_text = remove_weird_characters(comment_text)
                    author_id = row['author']
                    context = context_extractor(new_file, index)
                    nltk_tokens = comment_text.split()
                    new_comment_text_a = ''
                    new_comment_text_b = ''
                    section_a_id = 'a'
                    section_b_id = 'b'
                    for t in range(len(nltk_tokens)):
                        if t != len(nltk_tokens) - 1:
                            token_counter = t + 1
                            token = section_a_id + str(token_counter) + '_' + nltk_tokens[t] + ' '
                            new_comment_text_a += token
                            token = section_b_id + str(token_counter) + '_' + nltk_tokens[t] + ' '
                            new_comment_text_b += token
                        else:
                            token_counter = t + 1
                            token = section_a_id + str(token_counter) + '_' + nltk_tokens[t]
                            new_comment_text_a += token
                            token = section_b_id + str(token_counter) + '_' + nltk_tokens[t]
                            new_comment_text_b += token
                    new_comment_text_a.strip()
                    new_comment_text_b.strip()
                    row = [comment_id, title_id, community_id, title_text, new_comment_text_a, new_comment_text_b,
                           context, comment_text, str(comment_number), subthread, author_id, redirect_url, post_text]
                    temp_df = pd.DataFrame([row], columns=columns)
                    new_df = pd.concat([new_df, temp_df], ignore_index=True)
                batch_number += 1
                new_df.to_csv(
                    '/batches/' + str(
                        batch_number) + '.csv', sep=',')
                new_df = pd.DataFrame()





