import os
import pandas as pd
import re
import numpy as np
import csv

from itertools import islice

first_folder = '/final selected subthreads/batches'
second_folder = '/selection of 100/batches'
output_folder = '/final selected batches (toxic + non-toxic)'
row_limit = 30

def process_files(first_folder, second_folder, row_limit):
    removed_subthreads = []
    removed_comment = 0
    combined_files = []
    output_files = []
    first_folder_files = sorted(os.listdir(first_folder), key=lambda x: int(os.path.splitext(x)[0]))
    second_folder_files = sorted(os.listdir(second_folder), key=lambda x: int(os.path.splitext(x)[0]))
    first_folder_index = 0
    second_folder_index = 0
    name = ''

    while first_folder_index < len(first_folder_files) or second_folder_index < len(second_folder_files):
        for _ in range(4):
            if first_folder_index < len(first_folder_files):
                file_name = first_folder_files[first_folder_index]
                file_path = os.path.join(first_folder, file_name)
                match = re.search(r'/(\d+)\.csv$', file_path)
                folder_one_file_number = match.group(1)

                if os.path.isfile(file_path):
                    with open(file_path, 'r') as file:
                        reader = csv.reader(file)
                        rows = list(reader)
                        modified_rows = []
                        header_row = rows[0]
                        post_text_index = header_row.index("post_text")
                        comment = header_row.index("comment")
                        for row in rows[1:]:
                            modified_row = list(row)
                            post_text = modified_row[post_text_index]
                            c = modified_row[comment]
                            if c == '[removed]':
                                print(file_path)
                                removed_comment += 1
                                if folder_one_file_number not in removed_subthreads:
                                    removed_subthreads.append(folder_one_file_number)
                            modified_post_text = re.sub(r"http[s]?://\S+", "[LINK]", post_text)
                            modified_post_text = modified_post_text.replace('\n', ' ')
                            modified_post_text = modified_post_text.replace('[removed]', '___')
                            modified_row[post_text_index] = modified_post_text
                            modified_rows.append(modified_row)
                        rows = modified_rows

                        if len(combined_files) + len(rows) <= row_limit:
                            combined_files.extend(rows)
                            if folder_one_file_number != 1:
                                name = 'toxic ' + str(folder_one_file_number) if not name else name + ', ' + 'toxic ' + str(folder_one_file_number)
                            else:
                                name = 'toxic ' + str(folder_one_file_number)
                        else:
                            new_file_name = name + '.csv'
                            output_files.append((new_file_name, combined_files))
                            name = 'toxic ' + str(folder_one_file_number)
                            combined_files = []
                            combined_files.extend(rows)

                first_folder_index += 1

        if second_folder_index < len(second_folder_files):
            file_name = second_folder_files[second_folder_index]
            file_path = os.path.join(second_folder, file_name)
            match = re.search(r'/(\d+)\.csv$', file_path)
            folder_two_file_number = match.group(1)

            if os.path.isfile(file_path):
                with open(file_path, 'r') as file:
                    reader = csv.reader(file)
                    rows = list(reader)
                    modified_rows = []
                    header_row = rows[0]
                    post_text_index = header_row.index("post_text")
                    comment = header_row.index("comment")
                    for row in rows[1:]:
                        modified_row = list(row)
                        post_text = modified_row[post_text_index]
                        c = modified_row[comment]
                        if c == '[removed]':
                            print(file_path)
                            removed_comment += 1
                            if folder_two_file_number not in removed_subthreads:
                                removed_subthreads.append(folder_two_file_number)
                        modified_post_text = re.sub(r"http[s]?://\S+", "[LINK]", post_text)
                        modified_post_text = modified_post_text.replace('\n', ' ')
                        modified_post_text = modified_post_text.replace('[removed]', '___')
                        modified_row[post_text_index] = modified_post_text
                        modified_rows.append(modified_row)
                    rows = modified_rows
                    if len(combined_files) + len(rows) <= row_limit:
                        combined_files.extend(rows)
                        name = 'non-toxic ' + str(folder_two_file_number) if not name else name + ', ' + 'non-toxic ' + str(folder_two_file_number)
                    else:
                        new_file_name = name + '.csv'
                        output_files.append((new_file_name, combined_files))
                        name = 'non-toxic ' + str(folder_two_file_number)
                        combined_files = []
                        combined_files.extend(rows)

            second_folder_index += 1

    if combined_files:
        new_file_name = name + '.csv'
        output_files.append((new_file_name, combined_files))

    for output_file, rows in output_files:
        output_path = os.path.join(output_folder, output_file)
        with open(output_path, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(header_row)
            writer.writerows(rows)

    print(removed_comment)
    print(len(removed_subthreads))
    print(removed_subthreads)

# Process the files
process_files(first_folder, second_folder, row_limit)
