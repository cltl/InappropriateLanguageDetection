import os
import pandas as pd

# Read the meta_reddit-branching.csv file
meta_df = pd.read_csv("/meta_reddit-branching.csv", encoding='utf-8')

# Create an empty list to store the batch information
batch_info = []

# Get a list of all files in the "final selected batches (toxic + non-toxic)" folder
folder_path = "/final selected batches (toxic + non-toxic)"
file_list = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]

# Process each file (batch)
for file_name in file_list:
    if file_name == '.DS_Store':
        continue  # Skip .DS_Store file

    file_path = os.path.join(folder_path, file_name)

    try:
        # Read the file
        file_df = pd.read_csv(file_path, encoding='utf-8')

        # Match title_id and subthread_id columns in meta_df with file_df
        merged_df = pd.merge(meta_df, file_df, on=["title_id", "subthread_id"], how="inner")

        # Get required columns
        selected_columns = ["subthread_id", "title_id", "community_id"]
        merged_df = merged_df[selected_columns]

        # Calculate the required statistics for the batch
        unique_community_ids = merged_df["community_id"].nunique()
        unique_community_names = merged_df["community_id"].unique()
        unique_title_ids = merged_df["title_id"].nunique()
        unique_title_names = merged_df["title_id"].unique()
        unique_subthreads = merged_df["subthread_id"].nunique()
        unique_subthread_names = merged_df["subthread_id"].unique()
        row_count = file_df.shape[0]

        # Store the batch information as a dictionary
        batch_info.append({
            "Batch Name": file_name,
            "Unique Community IDs": unique_community_ids,
            "Community IDs": unique_community_names,
            "Unique Title IDs": unique_title_ids,
            "Title IDs": unique_title_names,
            "Unique Subthreads": unique_subthreads,
            "Subthreads": unique_subthread_names,
            "Number of Comments": row_count
        })

    except pd.errors.ParserError:
        print(f"Error parsing file: {file_name}")
        print(f"File path: {file_path}")
        continue

# Convert the list of dictionaries to a DataFrame
results_df = pd.DataFrame(batch_info)

# Export the results to a CSV file
results_df.to_csv("/statistics per batch.csv", index=False)

# Print the results
print(results_df)
