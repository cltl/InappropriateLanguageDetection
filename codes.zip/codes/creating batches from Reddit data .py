import os
from detect_delimiter import detect
class MyList(list):
    def last_index(self):
        return len(self)-1
rootdir = '/selection of 100/'
import pandas as pd
import nltk
limit = 0
batch = 0
def context_extractor(file, index):
    if index == 0:
        context = '-'
    elif index == 1:
        context = file.loc[index - 1, 'comment_text']
        context = str(context)
    else:
        context = file.loc[index - 2, 'comment_text']
        context = str(context)
        context = context + ' - ' + file.loc[index - 1, 'comment_text']
    return context
columns = ['comment_id', 'title_id', 'community_id', 'title_text', 'comment_text', 'context', 'comment', 'comment_number']
new_df = pd.DataFrame()
context = ''
batch_number = 0
for subdir, dirs, files in os.walk(rootdir):
    for file in files:
        file_path = os.path.join(subdir, file)
        if '.csv' in file_path:
            with open(file_path, newline='', errors='ignore') as csvfile:
                comment_number = 0
                limit += 1
                firstline = csvfile.readline()
                #delimiter = detect(firstline)
                new_file = pd.read_csv(file_path, on_bad_lines='skip')
                dataframe_length = len(new_file.index)
                for index, row in new_file.iterrows():
                    comment_id = row['comment_id']
                    comment_number += 1
                    title_id = row['title_id']
                    community_id = row['community_id']
                    title_text = row['title_text']
                    title_id = str(title_id)
                    comment_text = row['comment_text']
                    comment_text = str(comment_text)
                    context = context_extractor(new_file, index)
                    nltk_tokens = comment_text.split()
                    new_comment_text = ''

                    for t in range(len(nltk_tokens)):
                        if t != len(nltk_tokens) - 1:
                            token_counter = t + 1
                            token = str(token_counter) + '_' + nltk_tokens[t] + ' '
                            new_comment_text += token
                        else:
                            token_counter = t + 1
                            token = str(token_counter) + '_' + nltk_tokens[t]
                            new_comment_text += token
                    new_comment_text.strip()
                    row = [comment_id, title_id, community_id, title_text, new_comment_text, context, comment_text, str(comment_number)]
                    temp_df = pd.DataFrame([row], columns=columns)
                    new_df = new_df.append(temp_df, ignore_index=True)
                batch_number += 1
                new_df.to_csv(
                    '/selection of 100/batches' + str(
                        batch_number) + '.csv', sep=',')
                new_df = pd.DataFrame()





