import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np

# import required module
import os

# assign directory
Csv = pd.read_csv("selected data (6-8].csv", sep=',')
meta_df = pd.DataFrame(Csv)
#print(meta_df.shape)

df=meta_df.copy()
print(max(df['nr_comments']))
print(round(df['nr_comments'].mean(), 2))
print(max(df['nr_tokens']))
print(round(df['nr_tokens'].mean(), 2))
print(len(df. index))
print(df['nr_comments'].sum())