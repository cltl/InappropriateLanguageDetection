import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np

# import required module
import os

# assign directory
directory = os.getcwd() + "/final_data_branching_threads/metadata/"
filename_branch = os.getcwd() + "/final_data_branching_threads/metadata/meta_reddit-branching.csv"

for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    # checking if it is a file
    if os.path.isfile(f):
       if "branching" in filename:
            Csv = pd.read_csv(f, sep=',')
            meta_df = pd.DataFrame(Csv)

print(meta_df.shape)



df=meta_df.copy()
df['score2']= df['tox_score_general']/df['nr_tokens']

conditions = [
    df['nr_comments'].between(4,17),
    df['nr_tokens'].between(50,1000),
    df['max_tokens'] < 100,
    df['score2'] > 0.04,
    #df['tox_score_general'].between(4,20)
]

# filter rows of A where all of conditions are True
df=df.loc[np.bitwise_and.reduce(conditions)]
print("na selectie\t",df.shape)
#df=df.loc[np.bitwise_and.reduce(toxconditions)]
toxcolumns=["score2","nr_comments","tox_score_hurtlex","tox_score_wiegand","tox_score_stefan","tox_score_general"]
for  c in toxcolumns:
    print(df[c].describe())
