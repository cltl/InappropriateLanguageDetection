##### lengths of the conversation threads
import random
import csv
l = []
import pandas as pd
df = pd.read_csv ('meta_reddit-selected.csv', sep=',')
d = dict()
d["[0 - 1000]"] = 0
d["(1000 - 2000]"] = 0
d["(2000 - 3000]"] = 0
d["(3000 - 4000]"] = 0
d["(4000 - 5000]"] = 0
d["(5000 - 6000]"] = 0
d["(6000 - 7000]"] = 0
d["(7000 - 8000]"] = 0
from matplotlib import pyplot as plt
data = df['nr_tokens'].tolist()
print(max(data))
for index, row in df.iterrows():
    nr_tokens = row['nr_tokens']
    if nr_tokens <= 1000:
        d["[0 - 1000]"]  += 1
    elif nr_tokens <= 2000:
        d["(1000 - 2000]"]  += 1
    elif nr_tokens <= 3000:
        d["(2000 - 3000]"]  += 1
    elif nr_tokens <= 4000:
        d["(3000 - 4000]"]  += 1
    elif nr_tokens <= 5000:
        d["(4000 - 5000]"]  += 1
    elif nr_tokens <= 6000:
        d["(5000 - 6000]"]  += 1
    elif nr_tokens <= 7000:
        d["(6000 - 7000]"]  += 1
    elif nr_tokens <= 8000:
        d["(7000 - 8000]"]  += 1
width = 15
print(d)
plt.scatter(d.keys(), d.values(), width, color='r')
plt.xlabel('ranges of lengths')
plt.ylabel('frequency')
plt.xlim(-1,8)
plt.tight_layout(pad=5)
font = {'family': 'serif',
        'weight': 'normal',
        'size': 1,
        }
plt.xticks(rotation = 45)
plt.title('Lengths of the conversation threads', fontsize=10)
plt.legend()
plt.show()
######toxicity scores of the conversation threads
import random
import csv
l = []
import pandas as pd
df = pd.read_csv ('meta_reddit-selected.csv', sep=',')
d = dict()
d["[0 - 10]"] = 0
d["(10 - 20]"] = 0
d["(20 - 30]"] = 0
d["(30 - 40]"] = 0
d["(40 - 50]"] = 0
d["(50 - 60]"] = 0
from matplotlib import pyplot as plt
data = df['toxic_score'].tolist()
print(max(data))
for index, row in df.iterrows():
    toxic_score = row['toxic_score']
    if toxic_score <= 10:
        d["[0 - 10]"]  += 1
    elif toxic_score <= 20:
        d["(10 - 20]"]  += 1
    elif toxic_score <= 30:
        d["(20 - 30]"]  += 1
    elif toxic_score <= 40:
        d["(30 - 40]"]  += 1
    elif toxic_score <= 50:
        d["(40 - 50]"]  += 1
    elif toxic_score <= 60:
        d["(50 - 60]"]  += 1
width = 15
print(d)
plt.scatter(d.keys(), d.values(), width, color='r')
plt.xlabel('ranges of toxic scores')
plt.ylabel('frequency')
plt.xlim(-1, 6)
plt.tight_layout(pad=5)
font = {'family': 'serif',
        'weight': 'normal',
        'size': 1,
        }
plt.xticks(rotation = 45)
plt.title('Toxic scores of the conversation threads', fontsize=10)
plt.legend()
plt.show()
#####toxic percentage scores
import random
import csv
l = []
import pandas as pd
df = pd.read_csv ('meta_reddit-selected.csv', sep=',')
d = dict()
d["(0 - 10)"] = 0
d["(10 - 20)"] = 0
d["(20 - 30)"] = 0
d["(30 - 40)"] = 0
d["(40 - 50)"] = 0
d["(50 - 60)"] = 0
d["(60 - 70)"] = 0
d["(70 - 80)"] = 0
d["(80 - 90)"] = 0
d["(90 - 100)"] = 0
count = 0
from matplotlib import pyplot as plt
for index, row in df.iterrows():
    toxic_score = row['toxic_score']
    toxic_tokens = row['toxic-tokens']
    if toxic_tokens == 'NOT PROCESSED':
        pass
    else:
        if toxic_score != 0.0:
            print(toxic_tokens)
            toxic_tokens = toxic_tokens.split('/')
            toxic_tokens.pop(0)
            number_of_tokens = len(toxic_tokens)
            print(toxic_score)
            percentage = toxic_score/ number_of_tokens ** 100
            if percentage <= 10:
                d["(0 - 10)"]  += 1
            elif percentage <= 20:
                d["(10 - 20)"]  += 1
            elif percentage <= 30:
                d["(20 - 30)"]  += 1
            elif percentage <= 40:
                d["(30 - 40)"]  += 1
            elif percentage <= 50:
                d["(40 - 50)"]  += 1
            elif percentage <= 60:
                d["(50 - 60)"]  += 1
            elif percentage <= 70:
                d["(60 - 70)"]  += 1
            elif percentage <= 80:
                d["(70 - 80)"]  += 1
            elif percentage <= 90:
                d["(80 - 90)"]  += 1
            elif percentage <= 100:
                d["(90 - 100)"]  += 1
        else:
            d["(0 - 10)"] += 1
width = 15
print(d)
plt.scatter(d.keys(), d.values(), width, color='r')
plt.xlabel('ranges of toxic percentage scores')
plt.ylabel('frequency')
plt.xlim(-1, 10)
plt.tight_layout(pad=5)
font = {'family': 'serif',
        'weight': 'normal',
        'size': 1,
        }
plt.xticks(rotation = 45)
plt.title('Toxic percentage scores of the conversation threads', fontdict=font)
plt.legend()
plt.show()

#### Number of comments for conversation threads that are 1000 or less in length.
import random
import csv
l = []
import pandas as pd
df = pd.read_csv ('meta_reddit-selected.csv', sep=',')
d = dict()
d["[0 - 15]"] = 0
d["(15 - 30]"] = 0
d["(30 - 45]"] = 0
d["(45 - 60]"] = 0
d["(60 - 75]"] = 0
d["(75 - 90]"] = 0
d["(90 - 105]"] = 0
d["(105 - 120]"] = 0
d["(120 - 135]"] = 0
d["(135 - 150]"] = 0
from matplotlib import pyplot as plt
for index, row in df.iterrows():
    nr_tokens = row['nr_tokens']
    if nr_tokens <= 1000:
        nr_comments = row['nr_comments']
        if nr_comments <= 15:
            d["[0 - 15]"] += 1
        elif nr_comments <= 30:
            d["(15 - 30]"] += 1
        elif nr_comments <= 45:
            d["(30 - 45]"] += 1
        elif nr_comments <= 60:
            d["(45 - 60]"] += 1
        elif nr_comments <= 75:
            d["(60 - 75]"] += 1
        elif nr_comments <= 90:
            d["(75 - 90]"] += 1
        elif nr_comments <= 105:
            d["(90 - 105]"] += 1
        elif nr_comments <= 120:
            d["(105 - 120]"] += 1
        elif nr_comments <= 135:
            d["(120 - 135]"] += 1
        elif nr_comments <= 150:
            d["(135 - 150]"] += 1
width = 15
print(d)
plt.scatter(d.keys(), d.values(), width, color='r')
plt.xlabel('ranges of lengths')
plt.ylabel('frequency')
plt.xlim(-1,10)
plt.tight_layout(pad=5)
font = {'family': 'serif',
        'weight': 'normal',
        'size': 1,
        }
plt.xticks(rotation = 45)
plt.title('Number of comments for the conversation threads that are 1000 or less in length', fontsize=10)
plt.legend()
plt.show()
### toxic scores for threads with fewer than 1001 and 16 tokens and comments, respectively
import pandas as pd
df = pd.read_csv ('meta_reddit-selected.csv', sep=',')
d = dict()
l = []
d["[0 - 10]"] = 0
d["(10 - 20]"] = 0
d["(20 - 30]"] = 0
d["(30 - 40]"] = 0
d["(40 - 50]"] = 0
from matplotlib import pyplot as plt
data = df['toxic_score'].tolist()
for index, row in df.iterrows():
    toxic_score = row['toxic_score']
    nr_tokens = row['nr_tokens']
    if nr_tokens <= 1000:
        nr_comments = row['nr_comments']
        l.append(toxic_score)
        if nr_comments <= 15:
            if toxic_score <= 10:
                d["[0 - 10]"]  += 1
            elif toxic_score <= 20:
                d["(10 - 20]"]  += 1
            elif toxic_score <= 30:
                d["(20 - 30]"]  += 1
            elif toxic_score <= 40:
                d["(30 - 40]"]  += 1
            elif toxic_score <= 50:
                d["(40 - 50]"]  += 1
            elif toxic_score <= 60:
                d["(50 - 60]"]  += 1
width = 15
print(d)
plt.scatter(d.keys(), d.values(), width, color='r')
plt.xlabel('ranges of toxic scores')
plt.ylabel('frequency')
plt.xlim(-1, 5)
plt.tight_layout(pad=5)
font = {'family': 'serif',
        'weight': 'normal',
        'size': 1,
        }
plt.xticks(rotation = 45)
plt.title('Toxic scores of the conversation threads with fewer than 1001 and 16 tokens and comments, respectively', fontsize=7)
plt.legend()
plt.show()





