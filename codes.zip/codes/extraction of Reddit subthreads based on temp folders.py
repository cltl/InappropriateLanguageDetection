import pandas as pd
from pathlib import Path
import os
import matplotlib.pyplot as plt
import numpy as np

# import required module
import os
count = 0
file_count = 0
# assign directory
folder_directory = '/per toxicity level/'
files = ['(0.08-0.11]', '(0.11-0.12]', '(0.12-0.13]', '(0.13-0.14]', '(0.14-0.15]', '(0.15-0.16]', '(0.16-0.17]', '(0.17-0.18]', '(0.18-0.19]', '(0.19-0.2]']
for f in files:
    f_directory = folder_directory + 'selected data '+ f + '.csv'
    non_toxic = pd.read_csv(f_directory, sep=',')
    for index, row in non_toxic.iterrows():
        file_count += 1
        print(file_count)
        title_id = row['title_id']
        title_id = str(title_id)
        subthread_id = row['subthread_id']
        subthread_id = str(subthread_id)
        community = row['community']
        subthread = community + '_' + title_id + '_' + subthread_id + '.csv'
        for root, dirs, files in os.walk('/reddittemps'):
             for file in files:
                with open(os.path.join(root, file), "r") as auto:
                    auto = auto.name
                    file_directory, file_extension = os.path.splitext(auto)
                    file_directory = file_directory + file_extension
                    filename = Path(auto).stem
                    auto = filename + file_extension
                    if auto == subthread:
                        count+= 1
                        print('count: ', count)
                        new_file = pd.read_csv(file_directory, sep=',')
                        df = pd.DataFrame(new_file)
                        df.to_csv(
                            '/final selected subthreads/' + auto)


print(count)