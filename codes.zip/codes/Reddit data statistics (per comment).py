import os
import pandas as pd

# Get a list of all files in the "final selected batches (toxic + non-toxic)" folder
folder_path = "/final selected batches (toxic + non-toxic)"
file_list = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]

# Process each file (batch)
for file_name in file_list:
    if file_name == '.DS_Store':
        continue  # Skip .DS_Store file

    file_path = os.path.join(folder_path, file_name)

    try:
        # Read the file
        file_df = pd.read_csv(file_path, encoding='utf-8')

        # Group the file data by subthread_id
        subthread_groups = file_df.groupby("subthread_id")

        # Process each subthread within the batch
        for subthread_id, subthread_data in subthread_groups:
            # Get the unique subthread, community, and title IDs
            unique_community_id = subthread_data["community_id"].iloc[0]
            unique_title_id = subthread_data["title_id"].iloc[0]

            # Generate the file name based on subthread, community, and title IDs
            subthread_file_name = f"_s{subthread_id}_c{unique_community_id}_t{unique_title_id}.csv"
            subthread_file_path = os.path.join("/statistics per comment/", subthread_file_name)

            # Calculate the number of tokens for each comment in the subthread
            token_counts = subthread_data["comment_text_a"].str.split().str.len()

            # Create a DataFrame with the desired information
            subthread_info_df = pd.DataFrame({
                "comment_id": subthread_data["comment_id"],
                "number_of_tokens": token_counts,
                "subthread_id": subthread_id,
                "title_id": unique_title_id,
                "community_id": unique_community_id
            })

            # Save the subthread information to a separate file
            subthread_info_df.to_csv(subthread_file_path, index=False)

            print(f"Subthread information for subthread '{subthread_id}' in batch '{file_name}' saved to {subthread_file_path}")

    except pd.errors.ParserError:
        print(f"Error parsing file: {file_name}")
        print(f"File path: {file_path}")
        continue
