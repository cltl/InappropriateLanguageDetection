import os
from detect_delimiter import detect
rootdir = '/selected subthreads/'
import pandas as pd
lens = 0
count = 0
for subdir, dirs, files in os.walk(rootdir):
    for file in files:
        file_path = os.path.join(subdir, file)
        if '.csv' in file_path:
            with open(file_path, newline='', errors='ignore') as csvfile:
                count += 1
                firstline = csvfile.readline()
                delimiter = detect(firstline)
                new_file = pd.read_csv(file_path, sep=delimiter, on_bad_lines='skip', engine='python',encoding='ISO-8859-1')
                lens +=  len(new_file)
                print(lens)
average = lens/ count
print(average)

